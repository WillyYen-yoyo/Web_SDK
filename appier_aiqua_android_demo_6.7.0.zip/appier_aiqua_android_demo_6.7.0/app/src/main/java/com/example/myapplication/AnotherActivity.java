package com.example.myapplication;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.quantumgraph.sdk.QG;

import org.json.JSONException;
import org.json.JSONObject;

public class AnotherActivity extends AppCompatActivity {

    private QG qg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        qg = QG.getInstance(this);
        qg.onStart();

        JSONObject productDetails = new JSONObject();
        try {
            productDetails.put("id", "123");
//                productDetails.put("name", "Brand A Camera");
            productDetails.put("name", "AnotherActivity");
            productDetails.put("image_url", "https://aiqua.appier.com/media/squirrel.jpeg");
            productDetails.put("deep_link", "myapp//products?id=123");
            productDetails.put("type", "new");
            productDetails.put("category", "electronics");
            productDetails.put("brand", "Brand A");
            productDetails.put("color", "white");
            productDetails.put("size", "small");
            productDetails.put("price", 6999);
        } catch (JSONException e) {
        }
        qg.logEvent("product_viewed_Nick", productDetails);

    }
}
