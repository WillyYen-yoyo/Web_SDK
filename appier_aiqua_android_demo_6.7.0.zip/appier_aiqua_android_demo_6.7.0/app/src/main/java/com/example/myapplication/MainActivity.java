package com.example.myapplication;

import androidx.ads.identifier.AdvertisingIdInfo;
import androidx.annotation.Keep;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.quantumgraph.sdk.AiqInbox;
import com.quantumgraph.sdk.Completion;
import com.quantumgraph.sdk.QG;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Map;

import static android.provider.AlarmClock.EXTRA_MESSAGE;
import static androidx.constraintlayout.widget.Constraints.TAG;

import com.google.common.util.concurrent.Futures;

public class MainActivity extends AppCompatActivity {

    private static Context context;
    private QG qg;
    public String InboxValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;

        Button button = (Button) findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity();
            }
        });

        FirebaseMessagingServiceClass mFireMessaging = new FirebaseMessagingServiceClass();
        FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(context);

        JSONObjectClass t = new JSONObjectClass();

        FirebaseApp.initializeApp(context);

        qg = QG.getInstance(context);
        qg.onStart();


        //// Storing push notification
        QG.getInstance(context).enablePushNotificationStorage();
        JSONArray storedNotifications = QG.getInstance(context).getStoredNotifications();
        System.out.println("storedNotifications: "+ storedNotifications);


        Bundle params = new Bundle();
        params.putString("LoginTime", "time_stamp");
        mFirebaseAnalytics.logEvent("Logged_in2", params);

        QG.getInstance(context).getRecommendationForModelUserToProduct(new Completion() {
            @Override
            public void onComplete(JSONArray response) {
                for (int i=0; i<response.length(); i++) {

                    try {
                        System.out.println("Recommendation "+ response.getJSONObject(i).toString());

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        getADID u = new getADID();
        u.task.execute();

        t.setProfile();

        StoredNotifcation ttt = new StoredNotifcation();
        ttt.RetrieveStoredNotification();


        InboxData k = new InboxData();
        k.setMessageLimit();
        k.FetchInboxMessages();


        Button button2 = (Button) findViewById(R.id.button);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(String.valueOf(InboxValue)));
                startActivity(intent);

                System.out.println("InboxValue: "+ InboxValue);
            }
        });


        WebViewClass kkk = new WebViewClass();
        kkk.WebViewImplement();
    }


    public class WebViewClass{
        public void WebViewImplement() {

            WebView webView = findViewById(R.id.webview);
            WebSettings webSettings = webView.getSettings();
            webSettings.setJavaScriptEnabled(true);

            // important - inject Aiqua's JS interface
            QG.getInstance(context).addJavaScriptInterface(webView);

            webView.loadUrl("https://aiqua-php.herokuapp.com/");
        }
    }

    public class InboxData {

        public void FetchInboxMessages(){

            QG.fetchInboxMessages(context, new AiqInbox.FetchCallback() {
                @Override
                public void onInboxFetched(boolean success, String errMsg) {
                    AiqInbox[] inboxes = QG.getInboxes(true, true, true);
                    for (int i=0; i<inboxes.length; i++) {
                        String msg =
                                "title: " + inboxes[i].title + "\n" +
                                "text: "+ inboxes[i].text + "\n" +
                                "image url: " + inboxes[i].image + "\n" +
                                "deep link: " + inboxes[i].deepLink + "\n" +
                                "start time: " + inboxes[i].startTime + "\n" +
                                "end time: " + inboxes[i].endTime + "\n" +
                                "qgPayload: "  + inboxes[i].qgPayload + "\n" +
                                "status: " + inboxes[i].status;
                        Log.d("This_my_inbox:", "\n" + msg );

                        InboxValue = inboxes[i].image;
                    }
//                    inboxes[0].setStatus(getApplicationContext(), AiqInbox.Status.UNREAD); //Setting for message status
                }
            });
        }

        public void setMessageLimit(){
            int LimitNumber=100;
            QG.updateInboxRecordLimit(LimitNumber); // Default is 50
        }
    }


    public class StoredNotifcation {

        public void RetrieveStoredNotification(){
            JSONArray storedNotifications = QG.getInstance(context).getStoredNotifications();

            for (int i=0; i<storedNotifications.length(); i++) {

                try {
                    System.out.println("Stored_Notifications "+ storedNotifications.getJSONObject(i).toString());

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public void openNewActivity(){
        Intent intent = new Intent(this, AnotherActivity.class);
        startActivity(intent);
    }

    public static Context getcontext(){
        return context;
    }

    public class JSONObjectClass{

        QG qg = QG.getInstance(context.getApplicationContext());

        public void setProfile(){
            qg.setName("Nick");
            qg.setFirstName("Tsai");
            qg.setLastName("Test");
            qg.setCity("Taipei");
            qg.setEmail("nick.tsai@appier.com");
            qg.setDayOfBirth(17);
            qg.setMonthOfBirth(10);
            qg.setYearOfBirth(1988);
            qg.setPhoneNumber("123456789");
            qg.setCustomUserParameter("current_rating", 123);
        }

        public void setProfile2(){
            qg.setName("Nick");
            qg.setFirstName("Tsai");
            qg.setLastName("Test");
            qg.setCustomUserParameter("current_rating", 456);
        }

        public void registration(){
            JSONObject registrationDetails = new JSONObject();
            qg.logEvent("registration_completed", registrationDetails);

        }

        public void setEmail(){
            qg.setEmail("nick.tsai@appier.com");
        }

        public void category_viewed(){
            try {
                JSONObject categoryDetails = new JSONObject();
                categoryDetails.put("category", "apparels");
                qg.logEvent("category_viewed", categoryDetails);

            } catch (JSONException e) {
                Log.e("AIQUA DamoApp", "unexpected JSON exception", e);
            }

        }

        public void product_viewed(){
            JSONObject productDetails = new JSONObject();
            try {
                productDetails.put("id", "123");
//                productDetails.put("name", "Brand A Camera");
                productDetails.put("name", "許霈峯堃珮");
                productDetails.put("image_url", "https://aiqua.appier.com/media/squirrel.jpeg");
                productDetails.put("deep_link", "myapp//products?id=123");
                productDetails.put("type", "new");
                productDetails.put("category", "electronics");
                productDetails.put("brand", "Brand A");
                productDetails.put("color", "white");
                productDetails.put("size", "small");
                productDetails.put("price", 6999);
            } catch (JSONException e) {
            }
            qg.logEvent("product_viewed", productDetails);

        }

        public void product_added_to_cart(){
            JSONObject productDetails = new JSONObject();
            try {
                productDetails.put("id", "123");
                productDetails.put("name", "Brand A Camera");
                productDetails.put("image_url", "http://mysite.com/products/123.png");
                productDetails.put("deep_link", "myapp//products?id=123");
                productDetails.put("type", "new");
                productDetails.put("category", "electronics");
                productDetails.put("brand", "Brand A");
                productDetails.put("color", "white");
                productDetails.put("size", "small");
                productDetails.put("price", 6999);
            } catch (JSONException e) {
            }
            qg.logEvent("product_added_to_cart", productDetails);
        }

        public void product_added_to_wishlist() {
            JSONObject productDetails = new JSONObject();
            try {
                productDetails.put("id", "123");
                productDetails.put("name", "Brand A Camera");
                productDetails.put("image_url", "http://mysite.com/products/123.png");
                productDetails.put("deep_link", "myapp//products?id=123");
                productDetails.put("type", "new");
                productDetails.put("category", "electronics");
                productDetails.put("brand", "Brand A");
                productDetails.put("color", "white");
                productDetails.put("size", "small");
                productDetails.put("price", 6999);
            } catch (JSONException e) {
            }
            qg.logEvent("product_added_to_wishlist", productDetails);
        }

        public void product_purchased() {
            JSONObject productDetails = new JSONObject();
            try {
                productDetails.put("id", "123");
                productDetails.put("name", "Brand A Camera");
                productDetails.put("image_url", "http://mysite.com/products/123.png");
                productDetails.put("deep_link", "myapp//products?id=123");
                productDetails.put("type", "new");
                productDetails.put("category", "electronics");
                productDetails.put("brand", "Brand A");
                productDetails.put("color", "white");
                productDetails.put("size", "small");
                productDetails.put("price", 6999);
            } catch (JSONException e) {
            }
            qg.logEvent("product_purchased", productDetails);

        }

        public void checkout_initiated() {
            JSONObject checkoutDetails = new JSONObject();
            try {
                checkoutDetails.put("num_products", 2);
                checkoutDetails.put("cart_value", 12998.44);
                checkoutDetails.put("deep_link", "myapp://myapp/cart");
            } catch (JSONException e) {
            }
            qg.logEvent("checkout_initiated", checkoutDetails);
        }

        public void checkout_completed() {
            JSONObject checkoutCompleted = new JSONObject();
            try {
                checkoutCompleted.put("num_products", 2);
                checkoutCompleted.put("cart_value", 12998.44);
                checkoutCompleted.put("deep_link", "myapp://myapp/cart");
            } catch (JSONException e) {
            }
            qg.logEvent("checkout_completed", checkoutCompleted, 12998.44);
        }

        public void product_rated() {
            JSONObject rating = new JSONObject();
            try {
                rating.put("id", "1232");
                rating.put("rating", 2);
            } catch (JSONException e) {
            }
            qg.logEvent("product_rated", rating);
        }

        public void level() {
            JSONObject level = new JSONObject();
            try {
                level.put("level", 23);
            } catch (JSONException e) {
            }
            qg.logEvent("level", level);
        }

        public void my_custom_event() {
            JSONObject json = new JSONObject();
            try {
                json.put("my_param", "some value");
                json.put("some_other_param", 123);
                json.put("what_ever", 1234.23);
            } catch (JSONException e) {
            }
            qg.logEvent("my_custom_event", json);
        }
    }


    public class getADID {
        AsyncTask<Void, Void, String> task = new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                AdvertisingIdClient.Info idInfo = null;
                try {
                    idInfo = AdvertisingIdClient.getAdvertisingIdInfo(getApplicationContext());
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String advertId = null;
                try{
                    advertId = idInfo.getId();
                }catch (NullPointerException e){
                    e.printStackTrace();
                }

                return advertId;
            }

            @Override
            protected void onPostExecute(String advertId) {
                for (int i=0; i < 1000; i++) {
                    Toast.makeText(getApplicationContext(), advertId, Toast.LENGTH_SHORT).show();
                }

            }
        };
    }


}
