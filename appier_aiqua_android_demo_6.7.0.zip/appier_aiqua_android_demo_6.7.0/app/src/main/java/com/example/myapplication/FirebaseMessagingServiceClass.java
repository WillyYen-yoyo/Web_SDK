package com.example.myapplication;


import android.content.Context;
import android.content.Intent;
import android.util.Log;
import static androidx.constraintlayout.widget.Constraints.TAG;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.quantumgraph.sdk.NotificationJobIntentService;
import com.quantumgraph.sdk.QG;

import android.os.Bundle;
import androidx.core.app.JobIntentService;

import java.util.Map;


public class FirebaseMessagingServiceClass extends FirebaseMessagingService {
    public void onMessageReceived(RemoteMessage message) {

        String from = message.getFrom();
        Map data = message.getData();
        if (data.containsKey("message") && QG.isQGMessage(data.get("message").toString())) {
            Bundle qgData = new Bundle();
            qgData.putString("message", data.get("message").toString());
            Context context = getApplicationContext();

            if (from == null || context == null) {
                return;
            }
            Intent intent = new Intent(context, NotificationJobIntentService.class);
            intent.setAction("QG");
            intent.putExtras(qgData);
            JobIntentService.enqueueWork(context, NotificationJobIntentService.class, 1000, intent);
            return;
        }
    }

    public void onNewToken(String refreshedToken) {
        QG.logFcmId(getApplicationContext());
        Log.d(TAG, "Refreshed token: " + refreshedToken);
    }
}
