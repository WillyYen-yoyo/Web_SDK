package com.example.myapplication;

import android.app.Application;

import com.quantumgraph.sdk.QG;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        QG.initializeSdk(this,"-----Put Your AppId-----","-----Put Your SenderId-----");
    }
}
