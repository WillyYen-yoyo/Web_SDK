package com.example.myapplication;

import android.content.Context;

import androidx.annotation.Keep;

import com.quantumgraph.sdk.QG;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

@Keep
public class ProductView_ForGTM implements com.google.android.gms.tagmanager.CustomTagProvider {
    @Override

    public void execute(Map<String, Object> map) {
        synchronized (ProductView_ForGTM.class) {
            this.Product_View();
        }
    }

    public void Product_View() {
        QG qg = QG.getInstance(MainActivity.getcontext().getApplicationContext());
        JSONObject productDetails = new JSONObject();

        try {
            productDetails.put("id", "123");
            productDetails.put("name", "Brand A Camera");
            productDetails.put("image_url", "https://aiqua.appier.com/media/squirrel.jpeg");
            productDetails.put("deep_link", "myapp//products?id=123");
            productDetails.put("type", "new");
            productDetails.put("category", "electronics");
            productDetails.put("brand", "Brand A From GTM Real Test");
            productDetails.put("color", "white");
            productDetails.put("size", "small");
            productDetails.put("price", 6999);
        } catch (JSONException e) {
        }
        qg.logEvent("product_viewed", productDetails);

    }

}