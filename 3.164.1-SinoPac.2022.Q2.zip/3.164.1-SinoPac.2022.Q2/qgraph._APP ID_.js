window.QGSettings = {
   "appId": "<APP ID>",
   "debug": false,
   "origin": "<WEBSITE ORIGIN>"
};
if(window.qg && window.qg.queue) {
   window.qg.queue.unshift(('init', QGSettings));
}
!function(q,g,r,a,p,h,js){
   if(!q.qg){
       js=q.qg=function() {
           js.callmethod ? js.callmethod.call(js, arguments) : js.queue.push(arguments);
           js.queue = [];
       }
   }
   if(q.qg.initialized){return;}
   window.qg.queue.unshift(['init',window.QGSettings])
   p=g.createElement(r);
   p.async=!0;
   p.src=a;
   h=g.getElementsByTagName(r)[0];
   h.parentNode.insertBefore(p,h);
   q.qg.initialized = true;
}(window,document,'script','<URL/aiqua.securejs>');