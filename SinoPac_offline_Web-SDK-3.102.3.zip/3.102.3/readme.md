# 整合設定
更換檔案請洽 AIQUA Support

## 需確認項目
- appId
- WebPixel 檔案 (`qgraph.<APP ID>.js`)
- Web-SDK 檔案 (`aiqua.securejs`)

## 整合 Web-SDK

1. 將以下 js 文件添加到網頁內，確認可以直接用網址存取檔案，例如將 `qgraph.<APP ID>.js` 上傳到 `https://bank.sinopac.com/` 後，請確認 `https://bank.sinopac.com/qgraph.<APP ID>.js` 為可讀取狀態 。

附註：請重新命名 `qgraph.<APP ID>.js`，將 `<APP ID>` 換成提供的 `appId`, `appId` 可由 https://aiqua.appier.com/settings 頁面獲得

測試用 appId: 6ebd88521b2da5281593

```plan-text
qgraph.<APP ID>.js
aiqua.securejs
```

2. 修改 `qgraph.<APP ID>.js` 文件內容
- 將下方 `<APP ID>` 換成提供的 `appId`。
- 將下方 `<WEBSITE ORIGIN>` 換成您的網站主網址。例如 `https://bank.sinopac.com/`。
- 將下方 `<URL/aiqua.securejs>` 部分，換成第 1 步的 Web-SDK 檔案 `aiqua.securejs` 的真實網址。例如 `https://bank.sinopac.com/aiqua.securejs`。
- 如有更改檔案副檔名，請確實填入能存取的網址。

```javascript
window.QGSettings = {
   "appId": "<APP ID>",
   "debug": false,
   "origin": "<WEBSITE ORIGIN>"
};
// ... 省略
}(window,document,'script','<URL/aiqua.securejs>');
```

3. 在 INDEX.HTML 下新增以下的代碼。

附註：必須將下方 `<URL/qgraph.<APP ID>.js>` 部分，換成第 1 步的 WebPixel `qgraph.<APP ID>.js` 的真實網址。如有更改檔案副檔名，請確實填入能存取的網址。

```javascript
<script type="text/javascript">
  !function(q,g,r,a,p,h,js) {
    if(q.qg)return;
    js = q.qg = function() {
      js.callmethod ? js.callmethod.call(js, arguments) : js.queue.push(arguments);
    };
    js.queue = [];
    p=g.createElement(r);p.async=!0;p.src=a;h=g.getElementsByTagName(r)[0];
    h.parentNode.insertBefore(p,h);
  } (window,document,'script','<URL/qgraph.<APP ID>.js>');
</script>
```
